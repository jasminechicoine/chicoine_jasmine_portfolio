# Welcome to my super slay and aesthetic porfolio <3

Welcome to my Portfolio! This is a website I built from scratch to show my projects. 

~ Enjoy!

## Inspiration 

https://www.oliviatruong.design/
</br>
https://www.jeremy-stokes.com/
</br>
https://www.made-studio.es/proyectos


## Installation
Simply download the zip file and/or clone to your repo. 

## Usage 

Get a look at all my portfolio pieces and demo reel.


## Contributing
1. Fork it!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request :D

## Credits
Designer/Developer: [Jasmine Chicoine](https://github.com/jasminechicoine)


## License
MIT
